#include <stdio.h>

#include "core.h"
	
char* loadp = NULL;
char* savep = NULL;

bool cheat = false;
bool nofog = false;
bool sight = false;

char unify = 0;

int nummon = 10;
int numobj = 10;

int pcx = 0;
int pcy = 0;

unsigned int seed = 0;

